<?php

global $pronamic_ideal_errors;

foreach ( $pronamic_ideal_errors as $error ) {
	include 'error.php';
}
