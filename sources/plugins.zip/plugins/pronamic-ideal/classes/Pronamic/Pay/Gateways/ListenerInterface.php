<?php

/**
 * Title: Gateway listener interface
 * Description:
 * Copyright: Copyright (c) 2005 - 2016
 * Company: Pronamic
 *
 * @author Remco Tolsma
 * @version 1.0
 */
interface Pronamic_Pay_Gateways_ListenerInterface {
	public static function listen();
}
