<h2><?php esc_html_e( 'Follow Pronamic', 'pronamic_ideal' ); ?></h2>

<div style="margin: 1em 0;">
	<iframe src="https://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.facebook.com%2FPronamic&amp;send=false&amp;layout=standard&amp;width=600&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;height=24&amp;appId=208724019165734" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:600px; height:24px;" allowTransparency="true"></iframe>
</div>

<div style="margin: 1em 0;">
	<a href="https://twitter.com/pronamic" class="twitter-follow-button" data-show-count="false" data-lang="nl">@pronamic volgen</a>
	<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

	<div style="display: inline; margin: 0 2em;">
		<!-- Place this tag where you want the +1 button to render. -->
		<div class="g-plusone" data-annotation="inline" data-width="300" data-href="https://plus.google.com/111049280942725593214"></div>

		<!-- Place this tag after the last +1 button tag. -->
		<script type="text/javascript">
			(function() {
				var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
				po.src = 'https://apis.google.com/js/plusone.js';
				var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
			})();
		</script>
	</div>
</div>
