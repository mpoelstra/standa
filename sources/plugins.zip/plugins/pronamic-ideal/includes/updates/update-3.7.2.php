<?php

include dirname( __FILE__ ) . '/update-3.7.0.php';
